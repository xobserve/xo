const getDocs = () => [

]

export default getDocs
